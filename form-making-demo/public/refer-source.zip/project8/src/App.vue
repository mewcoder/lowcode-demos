<template>
  <div id="app">
    <form-making></form-making>
  </div>
</template>

<script>
import FormMaking from 'form-making-course'
import 'form-making-course/dist/FormMaking.css'

export default {
  name: 'app',
  components: {
    FormMaking
  }
}
</script>

<style lang="scss">
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
